package com.railway.TrainManagementService.Entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "trains")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Train {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int trainId;

    @Column(nullable = false)
    private String trainName;

    @Column(nullable = false)
    private String source;

    @Column(nullable = false)
    private String destination;

    @Column(nullable = false)
    private LocalDateTime departureTime;

    @Column(nullable = false)
    private  LocalDateTime arrivalTime;

    @Column(nullable = false)
    private int runningDays;

    @Column(nullable = false)
    private boolean availability;

    private String trainType;

    @CreationTimestamp
    private LocalDateTime created_At;

    @UpdateTimestamp
    private LocalDateTime updated_At;
}