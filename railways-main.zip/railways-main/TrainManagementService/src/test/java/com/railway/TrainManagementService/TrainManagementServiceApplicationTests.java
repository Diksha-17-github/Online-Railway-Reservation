package com.railway.TrainManagementService.Controller;

import com.railway.TrainManagementService.Entity.Train;
import com.railway.TrainManagementService.Service.TrainService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(MockitoExtension.class)
public class TrainManagementServiceApplicationTests {

	private MockMvc mockMvc;

	@Mock
	private TrainService trainService;

	@InjectMocks
	private TrainController trainController;

	@BeforeEach
	void setUp() {
		mockMvc = MockMvcBuilders.standaloneSetup(trainController).build();
	}

	@Test
	void testGetAllTrains() throws Exception {
		Train train1 = new Train(1, "Express", "CityA", "CityB");
		Train train2 = new Train(2, "Local", "CityC", "CityD");
		List<Train> trains = Arrays.asList(train1, train2);

		when(trainService.getAllTrains()).thenReturn(trains);

		mockMvc.perform(get("/api/trains")
						.contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.size()").value(trains.size()))
				.andExpect(jsonPath("$[0].name").value(train1.getName()))
				.andExpect(jsonPath("$[1].name").value(train2.getName()));
	}
}
