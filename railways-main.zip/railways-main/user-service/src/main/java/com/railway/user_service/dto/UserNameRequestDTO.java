package main.java.com.railway.user_service.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserNameRequestDTO {
    private String userName;
}
