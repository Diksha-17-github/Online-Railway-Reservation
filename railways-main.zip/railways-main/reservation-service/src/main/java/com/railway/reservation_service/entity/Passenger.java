package com.railway.reservation_service.entity;

public class Passenger {
}
