package com.railway.user_service.entity;

public enum Role {
    USER,
    ADMIN
}
