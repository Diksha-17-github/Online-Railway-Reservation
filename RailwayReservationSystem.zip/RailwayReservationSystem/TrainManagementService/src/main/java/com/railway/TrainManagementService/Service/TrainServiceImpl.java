package com.railway.TrainManagementService.Service;

import com.railway.TrainManagementService.Entity.Train;
import com.railway.TrainManagementService.Exception.TrainNotFoundException;
import com.railway.TrainManagementService.Repository.TrainRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class TrainServiceImpl implements TrainService {

    @Autowired
    private TrainRepository trainRepository;

    public List<Train> getAllTrains() {
        return trainRepository.findAll();
    }

    @Override
    public Train getTrainById(int id) {
        return trainRepository.findById(id)
                .orElseThrow(() -> new TrainNotFoundException("Train with ID " + id + " not found."));
    }


    public List<Train> searchTrains(String source, String destination) {
        return trainRepository.findBySourceAndDestination(source, destination);
    }

    public Train addTrain(Train train) {
        train.setCreated_At(LocalDateTime.now());
        train.setUpdated_At(LocalDateTime.now());
        return trainRepository.save(train);
    }

    public Train updateTrain(int id, Train updatedTrain) {
        Optional<Train> optionalTrain = trainRepository.findById(id);
        if (optionalTrain.isPresent()) {
            Train existingTrain = optionalTrain.get();
            existingTrain.setTrainName(updatedTrain.getTrainName());
            existingTrain.setSource(updatedTrain.getSource());
            existingTrain.setDestination(updatedTrain.getDestination());
            existingTrain.setDepartureTime(updatedTrain.getDepartureTime());
            existingTrain.setArrivalTime(updatedTrain.getArrivalTime());
            existingTrain.setRunningDays(updatedTrain.getRunningDays());
            existingTrain.setAvailability(updatedTrain.isAvailability());
            existingTrain.setTrainType(updatedTrain.getTrainType());
            existingTrain.setUpdated_At(LocalDateTime.now());
            return trainRepository.save(existingTrain);
        }
        return null;
    }

    public void deleteTrain(int id) {
        trainRepository.deleteById(id);
    }
}
