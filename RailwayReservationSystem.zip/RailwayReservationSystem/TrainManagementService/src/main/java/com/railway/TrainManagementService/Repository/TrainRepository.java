package com.railway.TrainManagementService.Repository;

import com.railway.TrainManagementService.Entity.Train;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface TrainRepository extends JpaRepository<Train, Integer> {
    List<Train> findBySourceAndDestination(String source, String destination);
}
