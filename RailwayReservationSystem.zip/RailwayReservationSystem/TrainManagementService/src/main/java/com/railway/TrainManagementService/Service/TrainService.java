package com.railway.TrainManagementService.Service;

import com.railway.TrainManagementService.Entity.Train;

import java.util.List;

public interface TrainService {
    List<Train> getAllTrains();
    Train getTrainById(int id);
    List<Train> searchTrains(String source, String destination);
    Train addTrain(Train train);
    Train updateTrain(int id, Train updatedTrain);
    void deleteTrain(int id);
}
