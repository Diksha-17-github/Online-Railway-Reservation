package com.railway.TrainManagementService;

import com.railway.TrainManagementService.Entity.Train;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest
class TrainManagementServiceApplicationTests {

	@Test
	void contextLoads() {
	}

	@Test
	void testTrainDetails() {
		Train train1 = Train.builder()
				.trainId(1)
				.trainName("Rajdhani")
				.source("Delhi")
				.destination("Mumbai")
				.departureTime(LocalDateTime.now())
				.arrivalTime(LocalDateTime.now().plusHours(5))
				.runningDays(5)
				.availability(true)
				.trainType("Sleeper")
				.build();

		Train train2 = Train.builder()
				.trainId(2)
				.trainName("Shatabdi")
				.source("Delhi")
				.destination("Chandigarh")
				.departureTime(LocalDateTime.now().plusHours(1))
				.arrivalTime(LocalDateTime.now().plusHours(4))
				.runningDays(3)
				.availability(true)
				.trainType("Seater")
				.build();

		assertEquals("Rajdhani", train1.getTrainName());
		assertEquals("Shatabdi", train2.getTrainName());
	}
}
