package com.railway.reservation_service.repository;

public class ReservationRepository {
}
