package com.railway.reservation_service.service;

public interface IReservationService {
}
