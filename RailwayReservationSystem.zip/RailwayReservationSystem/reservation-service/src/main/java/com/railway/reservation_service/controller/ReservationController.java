package com.railway.reservation_service.controller;

public class ReservationController {
}
