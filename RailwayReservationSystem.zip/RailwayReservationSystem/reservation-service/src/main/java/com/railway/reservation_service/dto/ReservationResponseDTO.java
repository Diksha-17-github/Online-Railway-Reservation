package com.railway.reservation_service.dto;

public class ReservationResponseDTO {
}
